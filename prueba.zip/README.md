# Ejemplo Clase Persona
## Atributos
1. ID
2. Nombre
3. Apellidos