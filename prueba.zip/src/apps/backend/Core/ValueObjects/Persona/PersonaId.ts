import { NumberValueObject } from "../../../shared/domain";

//* VALUE OBJECT PARA LOS APELLIDOS EN ESTE CASO DE NUMERICOS
//* HEREDA DE LA CLASE STRINGVALUEOBJECT Y ESTA A SU VES HEREDA DE VALUE OBJECT
export class PersonaId extends NumberValueObject{}