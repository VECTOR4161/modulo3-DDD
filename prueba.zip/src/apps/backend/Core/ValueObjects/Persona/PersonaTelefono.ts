import { StringValueObject } from "../../../shared/domain";

export class PersonaTelefono extends StringValueObject {}