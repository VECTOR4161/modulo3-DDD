import { StringValueObject } from "../../../shared/domain";

export class PersonaDni extends StringValueObject {}