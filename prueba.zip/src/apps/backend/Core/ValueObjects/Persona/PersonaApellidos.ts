import { StringValueObject } from "../../../shared/domain";


//* VALUE OBJECT PARA LOS APELLIDOS EN ESTE CASO DE STRING
//* HEREDA DE LA CLASE STRINGVALUEOBJECT Y ESTA A SU VES HEREDA DE VALUE OBJECT
export class PersonaApellidos extends StringValueObject{
    
}