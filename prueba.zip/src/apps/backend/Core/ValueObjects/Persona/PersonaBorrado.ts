import { BooleanValueObject } from "../../../shared/domain";

export class PersonaBorrado extends BooleanValueObject{}