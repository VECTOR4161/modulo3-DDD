import { BooleanValueObject } from "../../../shared/domain";

export class ClienteBorrado extends BooleanValueObject{}