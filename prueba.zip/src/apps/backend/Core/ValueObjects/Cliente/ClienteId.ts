import { NumberValueObject } from "../../../shared/domain";

export class ClienteId extends NumberValueObject{}