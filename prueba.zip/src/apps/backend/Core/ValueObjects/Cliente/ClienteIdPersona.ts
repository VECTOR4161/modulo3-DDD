import { NumberValueObject } from "../../../shared/domain";


export class ClienteIdPersona extends NumberValueObject{}