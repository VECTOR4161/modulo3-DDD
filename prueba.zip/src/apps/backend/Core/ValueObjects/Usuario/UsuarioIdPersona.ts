import { NumberValueObject } from "../../../shared/domain";


export class UsuarioIdPersona extends NumberValueObject{}