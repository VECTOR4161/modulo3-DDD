import { StringValueObject } from "../../../shared/domain";

export class UsuarioContrasena extends StringValueObject{}