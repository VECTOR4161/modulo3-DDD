import { NumberValueObject } from "../../../shared/domain";


export class UsuarioId extends NumberValueObject{}