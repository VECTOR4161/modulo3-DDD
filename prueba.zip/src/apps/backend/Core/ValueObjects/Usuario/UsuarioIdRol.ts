import { NumberValueObject } from "../../../shared/domain";

export class UsuarioIdRol extends NumberValueObject{}