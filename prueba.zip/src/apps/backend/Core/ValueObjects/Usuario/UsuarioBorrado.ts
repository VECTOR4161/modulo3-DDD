import { BooleanValueObject } from "../../../shared/domain";

export class UsuarioBorrado extends BooleanValueObject{}