import { ValueObject } from "..";

 export abstract class BooleanValueObject extends ValueObject<boolean> {}