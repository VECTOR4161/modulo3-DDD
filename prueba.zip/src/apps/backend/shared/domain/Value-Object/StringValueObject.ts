import { ValueObject } from "..";

 export abstract class StringValueObject extends ValueObject<string> {
    
 }